package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

EditText edtEmail;
EditText edtSenha;
Button btnLogar;


    Login Login = new Login("gabriel","admin", "123");

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        btnLogar = findViewById(R.id.btnLogar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    private void logar(String usuario,String senha){

        if(Login.autenticar(usuario,senha)){

            Toast.makeText(  this, "Usuario ou Senha Incorretos",Toast.LENGTH_SHORT).show();


        }

    }
}